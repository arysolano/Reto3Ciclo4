package com.usa.ciclo4.reto3ciclo4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Reto3Ciclo4ApplicationTests {

    @Test
    void contextLoads() {
    }

}
